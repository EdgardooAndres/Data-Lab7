package exceptionClasses;

public class NonEmptyTreeException extends RuntimeException {

	public NonEmptyTreeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NonEmptyTreeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
