package exceptionClasses;

public class EmptyTreeException extends RuntimeException {

	public EmptyTreeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmptyTreeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EmptyTreeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EmptyTreeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
